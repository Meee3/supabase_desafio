# Projeto

Teste Técnico 2: Gerador de Planos de Aula com IA
Objetivo
Desenvolver um sistema que gere planos de aula personalizados utilizando IA, com os
seguintes componentes:
● Introdução lúdica: Forma criativa e engajadora de apresentar o tema
● Objetivo de aprendizagem da BNCC: Alinhado à Base Nacional Comum Curricular
● Passo a passo da atividade: Roteiro detalhado para execução
● Rubrica de avaliação: Critérios para a professora avaliar o aprendizado
Requisitos Técnicos
Stack Obrigatória
● Backend: Supabase (banco de dados e autenticação)
● IA: Google AI Studio / Gemini API (uso gratuito sem cartão de crédito)
● Frontend: Livre escolha (ex: HTML puro, React, Next.js, Vue)
Etapas do Desenvolvimento
1. Pesquisa e Escolha do Modelo (20 pontos)
Tarefa: Acesse a documentação do Google AI Studio e escolha o modelo mais adequado.
2. Modelagem de Dados (30 pontos)
Tarefa: Defina quais inputs o usuário deve fornecer para que o plano de aula tenha qualidade e
crie a(s) tabela(s) no Supabase.
Entregável:
● Scripts SQL de criação das tabelas
● Diagrama ou descrição da estrutura de dados
3. Implementação do Gerador (50 pontos)Tarefa: Desenvolva a aplicação que:
1. Recebe os inputs do usuário através de uma interface (pode ser um html puro)
2. Envia uma requisição para a API do Gemini com um prompt estruturado
3. Processa a resposta da IA
4. Salva o plano de aula completo no Supabase
Requisitos funcionais:
● Formulário para entrada de dados
● Validação dos inputs
● Integração com Gemini API
● Parsing da resposta da IA (use JSON)
● Salvamento no banco de dados
● Exibição do plano de aula gerado
● Tratamento de erros
Entrega Final
O que enviar:
1. Repositório GitHub (público ou com acesso fornecido)
○ Código-fonte completo
○ README com instruções de setup
○ Documentação da escolha do modelo
○ Scripts SQL
2. Acessos aos projetos:
○ URL da aplicação
○ Credenciais de teste (se necessário)
○ Link para o projeto Supabase (ou export das tabelas)
3. Documentação:
○ README.md detalhado com:
■ Instruções de instalação
■ Como configurar as variáveis de ambiente
■ Como executar o projeto
■ Decisões técnicas tomadas
■ Desafios encontrados e soluções


#Sobre as API

Retirei minhas chaves mas está bem funcional

Com as chaves basta inserir em config.js e rodar  npx serve
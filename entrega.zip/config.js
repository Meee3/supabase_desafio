// Configurações da aplicação
// IMPORTANTE: Em produção, use variáveis de ambiente e um backend para proteger suas chaves

const CONFIG = {
  supabase: {
    url: '', // Ex: https://xxxxx.supabase.co
    anonKey: '' // Ex: eyJhbGc...
  },
  gemini: {
    apiKey: '', // Ex: AIzaSyD...
    model: 'gemini-2.0-flash'
  }
};
//Preenchendo a parte cima funciona
// Validação básica, 
if (CONFIG.supabase.url === 'YOUR_SUPABASE_URL' ||
  CONFIG.supabase.anonKey === 'YOUR_SUPABASE_ANON_KEY' ||
  CONFIG.gemini.apiKey === 'YOUR_GEMINI_API_KEY') {
  console.error('⚠️ ATENÇÃO: Configure suas credenciais no arquivo config.js');
}

-- Tabela para armazenar os planos de aula gerados
CREATE TABLE lesson_plans (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  subject VARCHAR(100) NOT NULL,
  grade VARCHAR(50) NOT NULL,
  duration INTEGER NOT NULL, -- duração em minutos
  theme VARCHAR(255) NOT NULL,
  resources TEXT,

  -- Componentes do plano de aula
  ludic_intro TEXT NOT NULL,
  bncc_objective TEXT NOT NULL,
  step_by_step TEXT NOT NULL,
  assessment_rubric TEXT NOT NULL,

  -- Metadata
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Índices para melhorar performance de queries
CREATE INDEX idx_lesson_plans_subject ON lesson_plans(subject);
CREATE INDEX idx_lesson_plans_grade ON lesson_plans(grade);
CREATE INDEX idx_lesson_plans_created_at ON lesson_plans(created_at DESC);

-- Trigger para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = TIMEZONE('utc', NOW());
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_lesson_plans_updated_at
  BEFORE UPDATE ON lesson_plans
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- RLS (Row Level Security) - opcional, caso queira adicionar autenticação depois
ALTER TABLE lesson_plans ENABLE ROW LEVEL SECURITY;

-- Política para permitir leitura pública (ajuste conforme necessário)
CREATE POLICY "Allow public read access" ON lesson_plans
  FOR SELECT USING (true);

-- Política para permitir inserção pública (ajuste conforme necessário)
CREATE POLICY "Allow public insert access" ON lesson_plans
  FOR INSERT WITH CHECK (true);
